import{default as t}from"../components/pages/devices.html/_page.svelte-ad198750.js";export{t as component};
