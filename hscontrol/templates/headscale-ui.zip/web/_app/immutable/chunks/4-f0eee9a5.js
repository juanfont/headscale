import{default as t}from"../components/pages/groups.html/_page.svelte-fb5e72e7.js";export{t as component};
