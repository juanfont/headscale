import{default as t}from"../components/pages/settings.html/_page.svelte-60e2722c.js";export{t as component};
