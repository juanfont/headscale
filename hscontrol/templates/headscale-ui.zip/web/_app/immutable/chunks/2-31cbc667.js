import{default as t}from"../components/pages/_page.svelte-42d9e92d.js";export{t as component};
