import{default as t}from"../components/error.svelte-79367385.js";export{t as component};
